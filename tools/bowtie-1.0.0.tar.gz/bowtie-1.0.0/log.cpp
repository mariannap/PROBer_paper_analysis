/*
 * log.cpp
 */

#include "log.h"

SyncLogger glog;
