/*=============================================================================
    Copyright (c) 2001-2011 Joel de Guzman

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

    This is an auto-generated file. Do not edit!
==============================================================================*/
namespace boost { namespace fusion
{
    template <typename T0>
    inline tuple<T0&>
    tie(T0 & _0)
    {
        return tuple<T0&>(
            _0);
    }
    template <typename T0 , typename T1>
    inline tuple<T0& , T1&>
    tie(T0 & _0 , T1 & _1)
    {
        return tuple<T0& , T1&>(
            _0 , _1);
    }
    template <typename T0 , typename T1 , typename T2>
    inline tuple<T0& , T1& , T2&>
    tie(T0 & _0 , T1 & _1 , T2 & _2)
    {
        return tuple<T0& , T1& , T2&>(
            _0 , _1 , _2);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3>
    inline tuple<T0& , T1& , T2& , T3&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3)
    {
        return tuple<T0& , T1& , T2& , T3&>(
            _0 , _1 , _2 , _3);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4>
    inline tuple<T0& , T1& , T2& , T3& , T4&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4)
    {
        return tuple<T0& , T1& , T2& , T3& , T4&>(
            _0 , _1 , _2 , _3 , _4);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5&>(
            _0 , _1 , _2 , _3 , _4 , _5);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13 , typename T14>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13 , T14 & _14)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13 , _14);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13 , typename T14 , typename T15>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13 , T14 & _14 , T15 & _15)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13 , _14 , _15);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13 , typename T14 , typename T15 , typename T16>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13 , T14 & _14 , T15 & _15 , T16 & _16)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13 , _14 , _15 , _16);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13 , typename T14 , typename T15 , typename T16 , typename T17>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16& , T17&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13 , T14 & _14 , T15 & _15 , T16 & _16 , T17 & _17)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16& , T17&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13 , _14 , _15 , _16 , _17);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13 , typename T14 , typename T15 , typename T16 , typename T17 , typename T18>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16& , T17& , T18&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13 , T14 & _14 , T15 & _15 , T16 & _16 , T17 & _17 , T18 & _18)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16& , T17& , T18&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13 , _14 , _15 , _16 , _17 , _18);
    }
    template <typename T0 , typename T1 , typename T2 , typename T3 , typename T4 , typename T5 , typename T6 , typename T7 , typename T8 , typename T9 , typename T10 , typename T11 , typename T12 , typename T13 , typename T14 , typename T15 , typename T16 , typename T17 , typename T18 , typename T19>
    inline tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16& , T17& , T18& , T19&>
    tie(T0 & _0 , T1 & _1 , T2 & _2 , T3 & _3 , T4 & _4 , T5 & _5 , T6 & _6 , T7 & _7 , T8 & _8 , T9 & _9 , T10 & _10 , T11 & _11 , T12 & _12 , T13 & _13 , T14 & _14 , T15 & _15 , T16 & _16 , T17 & _17 , T18 & _18 , T19 & _19)
    {
        return tuple<T0& , T1& , T2& , T3& , T4& , T5& , T6& , T7& , T8& , T9& , T10& , T11& , T12& , T13& , T14& , T15& , T16& , T17& , T18& , T19&>(
            _0 , _1 , _2 , _3 , _4 , _5 , _6 , _7 , _8 , _9 , _10 , _11 , _12 , _13 , _14 , _15 , _16 , _17 , _18 , _19);
    }
}}
