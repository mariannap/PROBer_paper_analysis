Other codes v0.1.0
==================

This package contains data analysis codes developed for experiments in the PROBer paper, which include a version of Spats* and PROBer 'separate' mode.
 